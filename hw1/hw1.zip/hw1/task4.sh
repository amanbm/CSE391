#!/bin/bash

####################################
# Name: <Your name here>
# CSE 391 - Spring 2020 
# Homework 1 - Task 4
####################################

function problem1 {
  # Type your answer to problem #1 below this line
  echo "Not yet implemented"
}

function problem2 {
  # Type your answer to problem #2 below this line
  echo "Not yet implemented"
}

function problem3 {
  # Type your answer to problem #3 below this line
  echo "Not yet implemented"
}

function problem4 {
  # Type your answer to problem #4 below this line
  echo "Not yet implemented"
}

function problem5 {
  # Type your answer to problem #5 below this line
  echo "Not yet implemented"
}

function problem6 {
  # Type your answer to problem #6 below this line
  echo "Not yet implemented"
}

function problem7 {
  # Type your answer to problem #7 below this line
  echo "Not yet implemented"
}

function problem8 {
  # Type your answer to problem #8 below this line
  echo "Not yet implemented"
}

function problem9 {
  # Type your answer to problem #9 below this line
  echo "Not yet implemented"
}

function problem10 {
  # Type your answer to problem #10 below this line
  echo "Not yet implemented"
}

function problem11 {
  # Type your answer to problem #11 below this line
  echo "Not yet implemented"
}

function problem12 {
  # Type your answer to problem #12 below this line
  echo "Not yet implemented"
}
